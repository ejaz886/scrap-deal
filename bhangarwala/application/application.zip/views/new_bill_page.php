<style>
   .dashboard_table th, .dashboard_table td{
    border: 1px dashed;
    padding: 5px;
  }
  .dashboard_table table{
    border: 1px dashed;
    border-collapse: collapse;
    width: 100%;
  }
  .form-group{
    display: block;
  }
  .center-screen {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
} 

</style>
<div>
  <div class="dashboard_table">
    <form action="<?php echo base_url()?>new_bill/set_bill_temp" method="post"> 
  <table>
    <tr>
      
      <td >
        Customer
        <select class="select2" name="Customer_Id" style="width: 100%;" id="customer_id">
          <option value="">Select Customer Name</option>
          <?php foreach($customer as $c){?>
          <option value="<?php echo $c->Customer_Id?>"><?php echo $c->Customer_Name?></option>
        <?php } ?>

        </select>
      </td>
      <td >
        <div>Customer Name:</div>
        <input type="text" id="Customer_Name" name="Customer_Name" readonly>

      </td>
      <td >
        <div>
          Customer Mobile:
        </div>
        <input type="text" id="Customer_Mobile" name="Customer_Mobile" readonly>
      </td>
      <td  align="center"><?php echo date("d-m-Y")?></td>
      <td  align="center">
        <button ><i class='fa fa-plus'></i></button>
      </td>
    </tr>
    
</table>
</form>

<table width="100%"> 
<tr>
  <th>Sr No</th>
  <th>Temp Bill No</th>
  <th>Customer Name</th>
  <th>Customer Mobile</th>
  <th>Discount</th>
  <th>Date</th>
  <th>Action</th>
</tr>
<?php $i=1; foreach($sale_head as $sh){?>

<tr>
  <th><?php echo $i?></th>
  <th><?php echo $sh->Sale_Id?></th>
  <th><?php echo $sh->Customer_Name?></th>
  <th><?php echo $sh->Customer_Mobile?></th>
  <th><?php echo $sh->Sale_Overall_Discount?></th>
  <th><?php echo $sh->Sale_Date?></th>
  <th>
    <a href="<?php echo base_url()."new_bill/add_new_item?Sale_Id=".$sh->Sale_Id?>"><i class="fa fa-edit"></i></a>
    <button onclick="delete_sale(<?php echo $sh->Sale_Id?>)"><i class="fa fa-trash"></i></button>

  </th>
</tr>
  <?php $i++; } ?>
</table>
</div>    
</div>
<script>
  $("#top_heading").html("New Bill");
  $("#top_button").hide();
  $("#customer_id").on("change",function(){
     $.ajax({
            type:"post",
            url:"<?php echo base_url()?>customer/edit",
            data:{"Customer_Id":$("#customer_id").val()},
            dataType:"text",
            success:function(resultData)
            {
                var json_d = JSON.parse(resultData);
                  $("#Customer_Name").val(json_d.Customer_Name);
                  $("#Customer_Mobile").val(json_d.Customer_Mobile);
            }
        })
  })

  function delete_sale(a)
{
  var check = confirm("Are You Sure....??")
  if(check){
  $.ajax({
            type:"post",
            url:"<?php echo base_url()?>new_bill/delete_sale_head",
            data:{"Sale_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                 var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },1000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
            }
        })
}
}
</script>