<style>
   .dashboard_table th, .dashboard_table td{
    border: 1px dashed;
    padding: 5px;
  }
  .dashboard_table table{
    border: 1px dashed;
    border-collapse: collapse;
    width: 100%;
  }
  .form-group{
    display: block;
  }
  .center-screen {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
} 

</style>
<div>
  <div class="dashboard_table">
    <form action="<?php echo base_url()?>purchase/set_bill_temp" method="post"> 
  <table>
    <tr>
      
      <td >
        Vendor
        <select class="select2" name="Vendor_Id" style="width: 100%;" id="Vendor_Id" required>
          <option value="">Select Vendor Name</option>
          <?php foreach($vendor as $c){?>
          <option value="<?php echo $c->Vendor_Id?>"><?php echo $c->Vendor_Name?></option>
        <?php } ?>

        </select>
      </td>
      <td >
        <div>Vendor Name:</div>
        <input type="text" id="Vendor_Name" name="Vendor_Name" readonly>

      </td>
      <td >
        <div>
          Vendor Mobile:
        </div>
        <input type="text" id="Vendor_Mobile" name="Vendor_Mobile" readonly>
      </td>
      <td >
        <div>
          Purchase Bill No:
        </div>
        <input type="text" name="Purchase_Bill_No" required>
      </td>
      <td  align="center">
        <input type="date" name="Purchase_Head_Date" value="<?php echo date("Y-m-d")?>" required >

      <td  align="center">
        <button ><i class='fa fa-plus'></i></button>
      </td>
    </tr>
    
</table>
</form>

<table width="100%"> 
<tr>
  <th>Sr No</th>
  <th>Purchase No</th>
  <th>Purchase Bill No</th>
  <th>Vendor Name</th>
  <th>Vendor Mobile</th>
  <th>Date</th>
  <th>Action</th>
</tr>
<?php $i=1; foreach($purchase_head as $sh){?>

<tr>
  <th><?php echo $i?></th>
  <th><?php echo $sh->Purchase_Head_Id?></th>
  <th><?php echo $sh->Purchase_Bill_No?></th>
  <th><?php echo $sh->Vendor_Name?></th>
  <th><?php echo $sh->Vendor_Mobile?></th>
  <th><?php echo $sh->Purchase_Head_Date?></th>
  <th>
    <a href="<?php echo base_url()."purchase/add_new_item?Purchase_Head_Id=".$sh->Purchase_Head_Id?>"><i class="fa fa-edit"></i></a>
    <button onclick="delete_sale(<?php echo $sh->Purchase_Head_Id?>)"><i class="fa fa-trash"></i></button>

  </th>
</tr>
  <?php $i++; } ?>
</table>
</div>    
</div>
<script>
  $("#top_heading").html("New Purchase");
  $("#top_button").hide();
  $("#Vendor_Id").on("change",function(){
     $.ajax({
            type:"post",
            url:"<?php echo base_url()?>vendor/edit",
            data:{"Vendor_Id":$("#Vendor_Id").val()},
            dataType:"text",
            success:function(resultData)
            {
                var json_d = JSON.parse(resultData);
                  $("#Vendor_Name").val(json_d.Vendor_Name);
                  $("#Vendor_Mobile").val(json_d.Vendor_Mobile);
            }
        })
  })

  function delete_sale(a)
{
  var check = confirm("Are You Sure....??")
  if(check){
  $.ajax({
            type:"post",
            url:"<?php echo base_url()?>purchase/delete_sale_head",
            data:{"Sale_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                 var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },1000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
            }
        })
}
}
</script>