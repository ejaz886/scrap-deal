<style>
   .dashboard_table td{
    border: 1px dashed;
  }
  .dashboard_table table{
    border: 1px dashed;
    border-collapse: collapse;
    width: 100%;
  }
</style>
<div>
  <div class="dashboard_table">
  <table>
    <tr>
      <td>Customer </td>
      <td>:0</td> 
      <td>Vendor </td>
      <td>:0</td> 
      <td>Sale </td>
      <td>:0</td> 
      <td>Category </td>
      <td>:0</td> 
      <td>item </td>
      <td>:0</td> 
      <td>Sale </td>
      <td>:0</td> 
    </tr>
</table>
</div>    
</div>
<script>
  $("#top_heading").html("Dashboard")
  </script>