<style>
   .dashboard_table th, .dashboard_table td{
    border: 1px dashed;
    padding: 5px;
  }
  .dashboard_table table{
    border: 1px dashed;
    border-collapse: collapse;
    width: 100%;
  }
  .form-group{
    display: block;
  }
  .center-screen {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  
} 
</style>
<div>
  <div class="dashboard_table">
  <table>
    <tr>
      <th>Sr No</th>
      <th>Category Name</th>
      <th>Action</th>
    </tr>
    <?php $i = 1; foreach($category as $c){?>
       <tr>
      <th><?php echo $i?></th>
      <th><?php echo $c->Item_Category_Name?></th>
      <th>
        <button onclick="show_edit(<?php echo $c->Item_Category_Id?>)"><i class='fa fa-edit'></i></button>
        <button onclick="$('#delete_modal').show();$('#Delete_Id').val(<?php echo $c->Item_Category_Id?>)"><i class='fa fa-trash'></i></button>
      </th>
    </tr>
    <?php $i++; } ?>
</table>
</div>    
</div>

<div id="modal_add" class="modal">
  <div class="modal-content" style="width: 40%;">
    <span class="close" onclick="$('#modal_add').hide()">&times;</span>
    <form id="save_form" action="<?php echo base_url()?>category/add_new_category" method='post' class='center-screen'>
      <div class="form-group">
        <div style='margin-bottom: 8px;'>Category Name</div>
        <input type="text" name="Item_Category_Name"><br>
        <button style='margin-top: 10px;'><i class='fa fa-save'></i> Save</button>
      </div>
    </form>
  </div>

</div>

<div id="edit_modal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="$('#edit_modal').hide()">&times;</span>
    <form id="update_form" action="<?php echo base_url()?>category/update" method='post' class='center-screen'>
        <input type="hidden" name="Item_Category_Id" id="Item_Category_Id">

      <div class="form-group">
        <div style='margin-bottom: 8px;'>Category Name</div>
        <input type="text" name="Item_Category_Name" id="Item_Category_Name"><br>
        <button style='margin-top: 10px;'><i class='fa fa-save'></i> Save</button>
      </div>
    </form>
  </div>

</div>

<div id="delete_modal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="$('#delete_modal').hide()">&times;</span>
    <p>Are You Sure ??</p>
    <input type='hidden' id="Delete_Id">
    <button onclick="delete_item($('#Delete_Id').val())">Yes</button>
    <button onclick="$('#delete_modal').hide();$('#Delete_Id').val('');">No</button>
  </div>

</div>

<script>
  $("#top_heading").html("Dashboard")
  function show_edit(a)
  {

 $.ajax({
            type:"post",
            url:"<?php echo base_url()?>category/edit",
            data:{"Item_Category_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                var json_d = JSON.parse(resultData);
                  $("#Item_Category_Id").val(json_d.Item_Category_Id);
                  $("#Item_Category_Name").val(json_d.Item_Category_Name);
                  $("#edit_modal").show();
            }
        })
  } 

  function delete_item(a)
  {

 $.ajax({
            type:"post",
            url:"<?php echo base_url()?>category/delete",
            data:{"Item_Category_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
            }
        })
  }

  $("#save_form").submit(function(e) {
         $(".loader").show();

        e.preventDefault(); // avoid to execute the actual submit of the form.

        var form = $(this);
        var url  = form.attr("action");
        
        $.ajax({
               type: "POST",
               url: url,
               data: new FormData(this),
               processData: false,
               contentType: false,
               success: function(resultData)
               {
          var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
               }
             });  
    }); 


  $("#update_form").submit(function(e) {
         $(".loader").show();

        e.preventDefault(); // avoid to execute the actual submit of the form.

        var form = $(this);
        var url  = form.attr("action");
        
        $.ajax({
               type: "POST",
               url: url,
               data: new FormData(this),
               processData: false,
               contentType: false,
               success: function(resultData)
               {
          var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
               }
             });  
    }); 

  </script>