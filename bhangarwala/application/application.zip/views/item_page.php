<style>
   .dashboard_table th, .dashboard_table td{
    border: 1px dashed;
    padding: 5px;
  }
  .dashboard_table table{
    border: 1px dashed;
    border-collapse: collapse;
    width: 100%;
  }
  .form-group{
    display: block;
  }
  .center-screen {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
} 

</style>
<div>
  <div class="dashboard_table">
  <table>
    <tr>
      <th>Sr No</th>
      <th>Item Code</th>
      <th>Category Name</th>
      <th>Item Desc</th>
      <th>Item Unit</th>
      <th>Item Rate</th>
      <th>Item Discount</th>
      <th>Tax</th>
      <th>Barcode</th>
      <th>Action</th>
    </tr>
    <?php $i = 1; foreach($item as $c){?>
       <tr>
      <th><?php echo $i?></th>
      <th><?php echo $c->Item_Code.$c->Item_Id?></th>
      <th><?php echo $c->Item_Category_Name?></th>
      <th><?php echo $c->Item_Description?></th>
      <th><?php echo $c->Item_Unit?></th>
      <th><?php echo $c->Item_Rate?></th>
      <th><?php echo $c->Item_Discount?></th>
      <th><?php echo $c->Item_Tax?></th>
      <th><a href="<?php echo base_url()?><?php echo $c->Item_Barcode?>" target="_blank"><i class="fa fa-barcode"></i></a></th>

      <th>
        <button onclick="show_edit(<?php echo $c->Item_Id?>)"><i class='fa fa-edit'></i></button>
        <button onclick="$('#delete_modal').show();$('#Delete_Id').val(<?php echo $c->Item_Id?>)"><i class='fa fa-trash'></i></button>
      </th>
    </tr>
    <?php $i++; } ?>
</table>
</div>    
</div>

<div id="modal_add" class="modal">
  <div class="modal-content" style="width: 40%;">
    <span class="close" onclick="$('#modal_add').hide()">&times;</span>
    <form id="save_form" action="<?php echo base_url()?>item/add" method='post' class='center-screen'>
            <input type="hidden" name="Item_Code" value="ARMAN">
      
      <div class="form-group dashboard_table">

        <table style='width:100%'>
          <tr>
            <td>Category Name</td>
            <td>
              <select name="Item_Category_Id" class="select2" style='width: 100%;'>
                <option value="">Select Item Category</option>
                  <?php foreach($category as $t){?>
                    <option value="<?php echo $t->Item_Category_Id?>"><?php echo $t->Item_Category_Name?></option>
                  <?php } ?>
              </select>
      </td>
          </tr>
          <tr>
            <td>Item Description</td>
            <td><input type="text" name="Item_Description"></td>
          </tr>
           <tr>
            <td>Unit Name</td>
            <td>
              <select name="Item_Unit" class="select2" style='width: 100%;'>
                <option value="">Select Unit</option>
                  <?php foreach($unit_master as $t){?>
                    <option value="<?php echo $t->Unit_Name?>"><?php echo $t->Unit_Name?></option>
                  <?php } ?>
              </select>
      </td>
          </tr>
          <tr>
            <td>Item Rate</td>
            <td><input type="text" name="Item_Rate"></td>
          </tr>
          <tr>
            <td>Item Discount</td>
            <td><input type="text" name="Item_Discount"></td>
          </tr> 
          <tr>
            <td>Item Tax</td>
            <td><input type="text" name="Item_Tax"></td>
          </tr>
          
          <tr>
            <td colspan="2">
        <button style='float: right;'><i class='fa fa-save'></i> Save</button>
            </td>
          </tr>
        </table>
      </div>
    </form>
  </div>

</div>

<div id="edit_modal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="$('#edit_modal').hide()">&times;</span>
    <form id="update_form" action="<?php echo base_url()?>item/update" method='post' class='center-screen'>
        <input type="hidden" name="Item_Id" id="Item_Id">

      <div class="form-group dashboard_table">

        <table style='width:100%'>
          <tr>
            <td>Category Name</td>
            <td>
              <select name="Item_Category_Id" id="Item_Category_Id" class="select2" style='width: 100%;'>
                <option value="">Select Item Category</option>
                  <?php foreach($category as $t){?>
                    <option value="<?php echo $t->Item_Category_Id?>"><?php echo $t->Item_Category_Name?></option>
                  <?php } ?>
              </select>
      </td>
          </tr>
          <tr>
            <td>Item Description</td>
            <td><input type="text" name="Item_Description" id="Item_Description"></td>
          </tr>
           <tr>
            <td>Unit Name</td>
            <td>
              <select name="Item_Unit" id="Item_Unit" style='width: 100%;'>
                <option value="">Select Unit</option>
                  <?php foreach($unit_master as $t){?>
                    <option value="<?php echo $t->Unit_Name?>"><?php echo $t->Unit_Name?></option>
                  <?php } ?>
              </select>
      </td>
          </tr>
          <tr>
            <td>Item Rate</td>
            <td><input type="text" name="Item_Rate" id="Item_Rate"></td>
          </tr>
          <tr>
            <td>Item Discount</td>
            <td><input type="text" name="Item_Discount" id="Item_Discount"></td>
          </tr> 
          <tr>
            <td>Item Tax</td>
            <td><input type="text" name="Item_Tax" id="Item_Tax"></td>
          </tr>
          <tr>
            <td>Item Barcode</td>
            <td><img src=''id="Item_Barcode" style="width: 100%;height:60px"></td>
          </tr>
          
          <tr>
            <td colspan="2">
        <button style='float: right;'><i class='fa fa-save'></i> Save</button>
            </td>
          </tr>
        </table>
      </div>
    </form>
  </div>

</div>

<div id="delete_modal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="$('#delete_modal').hide()">&times;</span>
    <p>Are You Sure ??</p>
    <input type='hidden' id="Delete_Id">
    <button onclick="delete_item($('#Delete_Id').val())">Yes</button>
    <button onclick="$('#delete_modal').hide();$('#Delete_Id').val('');">No</button>
  </div>

</div>

<script>
  $("#top_heading").html("Item Master")
  function show_edit(a)
  {

 $.ajax({
            type:"post",
            url:"<?php echo base_url()?>item/edit",
            data:{"Item_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                var json_d = JSON.parse(resultData);
                  $("#Item_Id").val(json_d.Item_Id);
                  $("#Item_Category_Id").select2("val",json_d.Item_Category_Id);
                  $("#Item_Description").val(json_d.Item_Description);
                  $("#Item_Rate").val(json_d.Item_Rate);
                  $("#Item_Discount").val(json_d.Item_Discount);
                  $("#Item_Tax").val(json_d.Item_Tax);
                  $("#Item_Unit").val(json_d.Item_Unit);
                  $("#Item_Barcode").attr("src",'<?php echo base_url()?>'+json_d.Item_Barcode);
                  $("#edit_modal").show();
            }
        })
  } 

  function delete_item(a)
  {

 $.ajax({
            type:"post",
            url:"<?php echo base_url()?>item/delete",
            data:{"Item_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
            }
        })
  }

  $("#save_form").submit(function(e) {
         $(".loader").show();

        e.preventDefault(); // avoid to execute the actual submit of the form.

        var form = $(this);
        var url  = form.attr("action");
        
        $.ajax({
               type: "POST",
               url: url,
               data: new FormData(this),
               processData: false,
               contentType: false,
               success: function(resultData)
               {
          var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
               }
             });  
    }); 


  $("#update_form").submit(function(e) {
         $(".loader").show();

        e.preventDefault(); // avoid to execute the actual submit of the form.

        var form = $(this);
        var url  = form.attr("action");
        
        $.ajax({
               type: "POST",
               url: url,
               data: new FormData(this),
               processData: false,
               contentType: false,
               success: function(resultData)
               {
          var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
               }
             });  
    }); 

  </script>