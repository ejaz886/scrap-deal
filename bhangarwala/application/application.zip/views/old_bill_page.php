<style>
   .dashboard_table th, .dashboard_table td{
    border: 1px dashed;
    padding: 5px;
  }
  .dashboard_table table{
    border: 1px dashed;
    border-collapse: collapse;
    width: 100%;
  }
  .form-group{
    display: block;
  }
  .center-screen {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
} 

</style>
<div>
  <div class="dashboard_table">
<table width="100%"> 
<tr>
  <th>Sr No</th>
  <th>Temp Bill No</th>
  <th>Customer Name</th>
  <th>Customer Mobile</th>
  <th>Discount</th>
  <th>Date</th>
  <th>Action</th>
</tr>
<?php $i=1; foreach($sale_head as $sh){?>

<tr>
  <th><?php echo $i?></th>
  <th><?php echo $sh->Sale_Id?></th>
  <th><?php echo $sh->Customer_Name?></th>
  <th><?php echo $sh->Customer_Mobile?></th>
  <th><?php echo $sh->Sale_Overall_Discount?></th>
  <th><?php echo $sh->Sale_Date?></th>
  <th>
    <a href="<?php echo base_url()."old_bill/add_new_item?Sale_Id=".$sh->Sale_Id?>"><i class="fa fa-edit"></i></a>
    <button onclick="delete_sale(<?php echo $sh->Sale_Id?>)"><i class="fa fa-trash"></i></button>

  </th>
</tr>
  <?php $i++; } ?>
</table>
</div>    
</div>
<script>
  $("#top_heading").html("Old Bill");
  $("#top_button").hide();
  

  function delete_sale(a)
{
  var check = confirm("Are You Sure....??")
  if(check){
  $.ajax({
            type:"post",
            url:"<?php echo base_url()?>old_bill/delete_sale_head",
            data:{"Sale_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                 var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },1000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
            }
        })
}
}
</script>