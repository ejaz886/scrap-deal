<style>
   .dashboard_table th, .dashboard_table td{
    border: 1px dashed;
    padding: 5px;
  }
  .dashboard_table table{
    border: 1px dashed;
    border-collapse: collapse;
    width: 100%;
  }
  .form-group{
    display: block;
  }
  .center-screen {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
} 

</style>
<div>
  <div class="dashboard_table">
    <form id="save_form" action="<?php echo base_url()?>accounting/add" method="post"> 
  <table>
    <tr>
      
      <td >
        Vendor
        <select class="select2" name="Vendor_Id" style="width: 100%;" id="Vendor_Id" required>
          <option value="">Select Vendor Name</option>
          <?php foreach($vendor as $c){?>
          <option value="<?php echo $c->Vendor_Id?>"><?php echo $c->Vendor_Name?></option>
        <?php } ?>

        </select>
      </td>
      <td >
        <div>Payment Type:</div>
        <select name="Accounting_Type" required style="width: 100%">
          <option value="">Select Type</option>
          <option value="BANK">BANK</option>
          <option value="CASH">CASH</option>
          <option value="SALE">SALE</option>
          <option value="PURCHASE">PURCHASE</option>
          <option value="EXTRA">EXTRA</option>
          <option value="SALARY">SALARY</option>
        </select>

      </td>
      <td >
        <div>
          Particuler:
        </div>
        <input type="text" name="Accounting_Particular" required>
      </td>
      <td >
        <div>
          Debit
        </div>
        <input type="text" name="Debit" >
      </td>
      <td >
        <div>
          Credit
        </div>
        <input type="text" name="Credit" >
      </td>
      <td  >
        <div>Date</div>
        <input type="date" name="Date" value="<?php echo date("Y-m-d")?>" required >

      <td  align="center">
        <button ><i class='fa fa-plus'></i></button>
      </td>
    </tr>
    
</table>
</form>

<table width="100%"> 
<tr>
  <th>Sr No</th>
  <th>Date</th>
  <th>Type Pay</th>
  <th>Vendor Name</th>
  <th>Vendor Mobile</th>
  <th>Note / Particular</th>
  <th>Debit</th>
  <th>Credit</th>
  <th>Balance</th>
  <th>Action</th>
</tr>
<?php $balance = 0;
 $t_debit = 0;
 $t_credit = 0;
$i=1; foreach($accounting as $sh){
$balance += $sh->Credit;
$balance -= $sh->Debit;


$t_debit += $sh->Debit;
$t_credit += $sh->Credit;
  ?>

<tr>
  <th><?php echo $i?></th>
  <th><?php echo date("d-m-y",strtotime($sh->Date))?></th>
  <th><?php echo $sh->Accounting_Type?></th>
  <th><?php echo $sh->Vendor_Name?></th>
  <th><?php echo $sh->Vendor_Mobile?></th>
  <th><?php echo $sh->Accounting_Particular?></th>
  <th><?php echo $sh->Debit?></th>
  <th><?php echo $sh->Credit?></th>
  <th><?php echo $balance?></th>
  
  <th>
    <button onclick="delete_sale(<?php echo $sh->Accouting_Id?>)"><i class="fa fa-trash"></i></button>

  </th>
</tr>
  <?php $i++; } ?>
  <tr>
    <th colspan="6"></th>
    <th align="center"><?php echo $t_debit?></th>
    <th align="center"><?php echo $t_credit?></th>
    <th align="center"><?php echo $t_credit - $t_debit?></th>
  </tr>
</table>
</div>    
</div>
<script>
  $("#top_heading").html("Accounting");
  $("#top_button").hide();
  

  function delete_sale(a)
{
  var check = confirm("Are You Sure....??")
  if(check){
  $.ajax({
            type:"post",
            url:"<?php echo base_url()?>accounting/delete",
            data:{"Accouting_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                 var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },1000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
            }
        })
}
}



  $("#save_form").submit(function(e) {
         $(".loader").show();

        e.preventDefault(); // avoid to execute the actual submit of the form.

        var form = $(this);
        var url  = form.attr("action");
        
        $.ajax({
               type: "POST",
               url: url,
               data: new FormData(this),
               processData: false,
               contentType: false,
               success: function(resultData)
               {
          var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
               }
             });  
    }); 


</script>