<html>
	<head>
		<style>

      .modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto; /* 15% from the top and centered */
  padding: 20px;
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* The Close Button */
.close {
  color: #aaa;
  float: right;
  font-size: 28px;
  font-weight: bold;
}

.close:hover,
.close:focus {
  color: black;
  text-decoration: none;
  cursor: pointer;
}

			.b_bottom{border-bottom: 1px dashed;}
.loader {
  border: 3px solid #d7d3d3;
  border-radius: 50%;
  border-top: 3px solid black;
  width: 50px;
  height: 50px;
  -webkit-animation: spin 1s linear infinite; /* Safari */
  animation: spin 1s linear infinite;
  position: absolute;
  top: 48%;
  left: 48%;
  display: none;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

a{text-decoration: none;}

		</style>
		<link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/fontawesome-free/css/all.css">
    <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/select2/css/select2.css">
    <script src="<?php echo base_url()?>assets/plugins/jquery/jquery.min.js"></script>
		<script src="<?php echo base_url()?>assets/plugins/sweetalert2/sweetalert2.min.js"></script>
    <script src="<?php echo base_url()?>assets/plugins/select2/js/select2.js"></script>
    <script>
      const Toast = Swal.mixin({
                  position: "center",
                  showConfirmButton: false,
                  timer: 3000
              });
    </script>
	</head>
	<body>
		<div class="loader"></div>
    <div style='display: block; position: absolute;left: 0px;width: 200px;border-right: 1px dashed;height: 100%;'>
      <ul style="list-style: none;padding: 0px;margin-top: 0px;font-weight: bold;">

        <li style='border-bottom:1px dashed;padding:10px'>ARMAN COLLECTION</li>
        
        <li style='border-bottom:1px dashed;padding:10px'><a href="<?php echo base_url()?>dashboard">Dashboard</a></li>
        
        <li style='border-bottom:1px dashed;padding:10px' onclick="$('.master').toggle();">Master <span style='float: right;'><i class='fa fa-arrow-down'></i></span></li>  
        
        <li style='border-bottom:1px dashed;padding:10px;display: none;' class='master'><a href="<?php echo base_url()?>category"><span style="padding-left:10px">Category</span></a></li>
        
        <li style='border-bottom:1px dashed;padding:10px;display: none;' class='master'><a href="<?php echo base_url()?>item"><span style="padding-left:10px">Item</span></a></li>
        
        <li style='border-bottom:1px dashed;padding:10px'  onclick="$('.sale').toggle();">Sale <span style='float: right;'><i class='fa fa-arrow-down'></i></span></li>
        
        <li style='border-bottom:1px dashed;padding:10px;display: none;' class='sale'><a href="<?php echo base_url()?>customer"><span style="padding-left:10px">Customer</span></a></li>
        
        <li style='border-bottom:1px dashed;padding:10px;display: none;' class='sale'><a href="<?php echo base_url()?>new_bill?Sale_Id=0"><span style="padding-left:10px">New Bill</span></a></li>
        <li style='border-bottom:1px dashed;padding:10px;display: none;' class='sale'><a href="<?php echo base_url()?>old_bill"><span style="padding-left:10px">Old Bill</span></a></li>
        
        <li style='border-bottom:1px dashed;padding:10px' onclick="$('.purchase').toggle();">Purchase <span style='float: right;'><i class='fa fa-arrow-down'></i></span></li>
        <li style='border-bottom:1px dashed;padding:10px;display: none;' class='purchase'><a href="<?php echo base_url()?>vendor"><span style="padding-left:10px">Vendor</span></a></li>
        <li style='border-bottom:1px dashed;padding:10px;display: none;' class='purchase'><a href="<?php echo base_url()?>purchase"><span style="padding-left:10px">New Purchase</span></a></li>
        <li style='border-bottom:1px dashed;padding:10px'>Stock</li>
        <li style='border-bottom:1px dashed;padding:10px'><a href="<?php echo base_url()?>accounting">Account</a></li>
        <li style='border-bottom:1px dashed;padding:10px'>Report</li>
      </ul>
    </div>
    <div style="margin-left: 194px;">
        <div style="height: 38px;border-bottom: 1px dashed;padding-left: 10px;font-size: 20px;font-weight: bold;">
          <span id="top_heading"></span>
          <button id="top_button" style='float: right;' onclick="$('#modal_add').show()"><i class='fa fa-plus'></i></button>
        </div>     
        <div style="padding-left: 10px;padding-top: 10px;">
          <?php if(!empty($page)){
      $this->load->view($page);
    }
      ?></div> 
    </div>
    <script>
      $('.select2').select2()
    </script>
	</body>
	</html>