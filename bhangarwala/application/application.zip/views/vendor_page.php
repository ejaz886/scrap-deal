<style>
   .dashboard_table th, .dashboard_table td{
    border: 1px dashed;
    padding: 5px;
  }
  .dashboard_table table{
    border: 1px dashed;
    border-collapse: collapse;
    width: 100%;
  }
  .form-group{
    display: block;
  }
  .center-screen {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  
}  
</style>
<div>
  <div class="dashboard_table">
  <table>
    <tr>
      <th>Sr No</th>
      <th>Vendor Name</th>
      <th>Vendor Mobile</th>
      <th>Vendor Address</th>
      <th>Action</th>
    </tr>
    <?php $i = 1; foreach($vendor as $c){?>
       <tr>
      <th><?php echo $i?></th>
      <th><?php echo $c->Vendor_Name?></th>
      <th><?php echo $c->Vendor_Mobile?></th>
      <th><?php echo $c->Vendor_Address?></th>
      <th>
        <button onclick="show_edit(<?php echo $c->Vendor_Id?>)"><i class='fa fa-edit'></i></button>
        <button onclick="$('#delete_modal').show();$('#Delete_Id').val(<?php echo $c->Vendor_Id?>)"><i class='fa fa-trash'></i></button>
      </th>
    </tr>
    <?php $i++; } ?>
</table>
</div>    
</div>

<div id="modal_add" class="modal">
  <div class="modal-content" style="width: 40%;">
    <span class="close" onclick="$('#modal_add').hide()">&times;</span>
    <form id="save_form" action="<?php echo base_url()?>vendor/add" method='post' class='center-screen'>
      <div class="dashboard_table">
        <table>
            <tr>
                <td colspan="2">Add New Vendor</td>
            </tr>
            <tr>
                <td>Vendor Name</td>
                <td><input type="text" name="Vendor_Name"></td>
            </tr>
            <tr>
                <td>Vendor Mobile</td>
                <td><input type="text" name="Vendor_Mobile"></td>
            </tr>
            <tr>
                <td>Vendor Address</td>
                <td><input type="text" name="Vendor_Address"></td>
            </tr>
            <tr>
       
                <td colspan="2"> <button style='float:right'><i class='fa fa-save'></i> Save</button></td>
            </tr>
        </table>
      </div>
    </form>
  </div>

</div>

<div id="edit_modal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="$('#edit_modal').hide()">&times;</span>
    <form id="update_form" action="<?php echo base_url()?>vendor/update" method='post' class='center-screen'>
        <input type="hidden" name="Vendor_Id" id="Vendor_Id">

      <div class="dashboard_table">
 <table>
            <tr>
                <td colspan="2">Update New Vendor</td>
            </tr>
            <tr>
                <td>Vendor Name</td>
                <td><input type="text" name="Vendor_Name" id="Vendor_Name"></td>
            </tr>
            <tr>
                <td>Vendor Mobile</td>
                <td><input type="text" name="Vendor_Mobile" id="Vendor_Mobile"></td>
            </tr> 
            <tr>
                <td>Vendor Address</td>
                <td><input type="text" name="Vendor_Address" id="Vendor_Address"></td>
            </tr>
            <tr>
       
                <td colspan="2"> <button style='float:right'><i class='fa fa-save'></i> Save</button></td>
            </tr>
        </table>
      </div>
    </form>
  </div>

</div>

<div id="delete_modal" class="modal">
  <div class="modal-content">
    <span class="close" onclick="$('#delete_modal').hide()">&times;</span>
    <p>Are You Sure ??</p>
    <input type='hidden' id="Delete_Id">
    <button onclick="delete_item($('#Delete_Id').val())">Yes</button>
    <button onclick="$('#delete_modal').hide();$('#Delete_Id').val('');">No</button>
  </div>

</div>

<script>
  $("#top_heading").html("Vendor")
  function show_edit(a)
  {

 $.ajax({
            type:"post",
            url:"<?php echo base_url()?>vendor/edit",
            data:{"Vendor_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                var json_d = JSON.parse(resultData);
                  $("#Vendor_Id").val(json_d.Vendor_Id);
                  $("#Vendor_Name").val(json_d.Vendor_Name);
                  $("#Vendor_Mobile").val(json_d.Vendor_Mobile);
                  $("#Vendor_Address").val(json_d.Vendor_Address);
                  $("#edit_modal").show();
            }
        })
  } 

  function delete_item(a)
  {

 $.ajax({
            type:"post",
            url:"<?php echo base_url()?>vendor/delete",
            data:{"Vendor_Id":a},
            dataType:"text",
            success:function(resultData)
            {
                var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
            }
        })
  }

  $("#save_form").submit(function(e) {
         $(".loader").show();

        e.preventDefault(); // avoid to execute the actual submit of the form.

        var form = $(this);
        var url  = form.attr("action");
        
        $.ajax({
               type: "POST",
               url: url,
               data: new FormData(this),
               processData: false,
               contentType: false,
               success: function(resultData)
               {
          var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
               }
             });  
    }); 


  $("#update_form").submit(function(e) {
         $(".loader").show();

        e.preventDefault(); // avoid to execute the actual submit of the form.

        var form = $(this);
        var url  = form.attr("action");
        
        $.ajax({
               type: "POST",
               url: url,
               data: new FormData(this),
               processData: false,
               contentType: false,
               success: function(resultData)
               {
          var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
               }
             });  
    }); 

  </script>