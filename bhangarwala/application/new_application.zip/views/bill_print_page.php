
<!-- <button id="x1x" style="float:right;padding:10px;background-color:green;color:white;font-size:20px" onclick="printdiv('print_data')">Print</button> -->
<div  id="print_data" >
<style>
table {
  border-collapse: collapse;
}

table, th, td {

}
@page { margin: 0 }
body { margin: 0 }
.sheet {
  margin: 0;
  overflow: hidden;
  position: relative;
  box-sizing: border-box;
  page-break-after: always;
}

/** Paper sizes **/
body.A3           .sheet { width: 297mm; height: 419mm }
body.A3.landscape .sheet { width: 420mm; height: 296mm }
body.A4           .sheet { width: 210mm; height: 296mm }
body.A4.landscape .sheet { width: 297mm; height: 209mm }
body.A5           .sheet { width: 148mm; height: 209mm }
body.A5.landscape .sheet { width: 210mm; height: 147mm }

/** Padding area **/
.sheet.padding-10mm { padding: 10mm }
.sheet.padding-15mm { padding: 15mm }
.sheet.padding-20mm { padding: 20mm }
.sheet.padding-25mm { padding: 25mm }

/** For screen preview **/
@media screen {
  body { background: #e0e0e0 }
  .sheet {
    background: white;
    box-shadow: 0 .5mm 2mm rgba(0,0,0,.3);
    margin: 5mm;
  }
}

/** Fix for Chrome issue #273306 **/
@media print {
           body.A3.landscape { width: 420mm }
  body.A3, body.A4.landscape { width: 297mm }
  body.A4, body.A5.landscape { width: 210mm }
  body.A5                    { width: 148mm }
}
</style>
<div class="A5" >
 <div style="margin-top:120px;margin-bottom:60px;margin-right:70px;margin-left:70px">
<p style="padding:10px;"><b>Bill No :- <span id ="bno"><?php echo $sale_head->Sale_Id?></span>
<b><span style="padding-right:10px;float:right" id ="bdate"><?php echo date("d-m-Y",strtotime($sale_head->Sale_Date))?></span></p>
</div>
<table style="margin-left:60px;width:4.70in">

<?php $total=0;
$discount = 0;
$i = 1;
$bottom = 0;
foreach($sale_item as $ty){
		$x_main_item_total = $ty["Item_Rate"] * $ty["Item_Qty"];
		$x_discounts = ($x_main_item_total * $sale_head->Sale_Overall_Discount)/100;
		$x_item_dis = $x_main_item_total - ($x_discounts);
		$bottom += $x_item_dis;
	?>
	<tr>
		<td style="width:0.5in"><?php echo $i;?></td>
		<td style="width:2.2in"><?php echo $ty["Item_Discription"]?></td>
		<td style="width:0.9in"><?php echo $ty["Item_Rate"]?></td>
		<td style="width:0.9in"><?php echo $ty["Item_Qty"]?></td>
		<td style="width:1.1in"><?php echo $x_main_item_total."(".$x_item_dis.")";?></td>
	</tr> 
	<?php $total += ($ty["Item_Rate"] * $ty["Item_Qty"]);
			$discount = $x_item_dis;

?>
<?php $i++; }?>

</table>
<div style="position: fixed;
  bottom: 1.8in;
  right: 0.5in;
  font-weight: normal;
  width: 100px;"
  
  >
<span style="margin-bottom:20px"><?php echo $total;?></span><br>
<?php //echo $headss->Sale_Discount;?>
<span style="margin-bottom:20px"><?php echo "-".round((($total * $sale_head->Sale_Overall_Discount)/100));?></b><br>
<b><?php echo round($total - (($total * $sale_head->Sale_Overall_Discount)/100))?></b>
</div>
</div>
<script>	 
//setInterval(printdiv('print_data'), 300);
printdiv('print_data');
function printdiv(x)
{  

    var printContents = document.getElementById(x).innerHTML;
     var originalContents = document.body.innerHTML;

     document.body.innerHTML = printContents;
     window.print();

     document.body.innerHTML = originalContents;

}
</script>