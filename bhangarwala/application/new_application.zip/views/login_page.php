<html>
	<head>
		<style>
			.center-screen {
  display: flex;
  justify-content: center;
  align-items: center;
  text-align: center;
  min-height: 100vh;
}	
.loader {
  border: 3px solid #d7d3d3;
  border-radius: 50%;
  border-top: 3px solid black;
  width: 50px;
  height: 50px;
  -webkit-animation: spin 1s linear infinite; /* Safari */
  animation: spin 1s linear infinite;
  position: absolute;
  top: 48%;
  left: 48%;
  display: none;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
.login_center{
	width: 250px;
	height: 200px;
	border: 1px solid;
}
.button_div{
	margin-top: 10px;
}


		</style>
		<link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
		<script src="<?php echo base_url()?>assets/plugins/sweetalert2/sweetalert2.min.js"></script>
		<script src="<?php echo base_url()?>assets/plugins/jquery/jquery.min.js"></script>
	</head>
	<body>
		<div class="loader" >
		</div>
		<div class="center-screen">
			<div class="login_center">
				<form id="check_login" action="<?php echo base_url()?>login/check_login" method="post">
					<div>
						<h5>Login Panel</h5>
					</div>
					<div class="button_div">
						<label>USERNAME</label>
						<input type="text" name="Username" id="Username">
					</div>
					<div class="button_div">
						<label>PASSWORD</label>
						<input type="text" name="Password" id="Password" >
					</div>
					<div>
						<button class="button_div">Login</button>
					</div>
				</form>
			</div>

		</div>
	</body>
</html>
<script>
	const Toast = Swal.mixin({
                  position: "center",
                  showConfirmButton: false,
                  timer: 3000
              });
	$("#check_login").submit(function(e) {
         $(".loader").show();

        e.preventDefault(); // avoid to execute the actual submit of the form.

        var form = $(this);
        var url  = form.attr("action");
        
        $.ajax({
               type: "POST",
               url: url,
               data: new FormData(this),
               processData: false,
               contentType: false,
               success: function(resultData)
               {
     			var json_d = JSON.parse(resultData);

               if(json_d.response)
                     {
                      
                        Toast.fire({
                            type: "success",
                            title: json_d.msg
                        })
                        setTimeout(function(){
                         location.reload();
                     },3000);
                    }
                    else{
                        Toast.fire({
                            type: "error",
                            title: json_d.msg
                        })
                    }
                    $(".loader").hide();
               }
             });  
    }); 
</script>